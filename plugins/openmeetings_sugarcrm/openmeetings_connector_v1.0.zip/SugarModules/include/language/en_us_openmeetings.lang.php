<?php
$GLOBALS['app_list_strings']['_list_openmeetings_language_']=array (
  1 => 'English',
  2 => 'German',
  3 => 'Russian',
  4 => 'French',
);

