<?php
// created: 2008-06-06 11:53:13
$mod_strings = array_merge($mod_strings,
    array(
 'VALUE' => 'OPENMEETINGS home',    
  'LBL_OPENMEETINGS_STARTADHOC' => 'My OpenMeetings Room', 
       
   )
  )
  ;


?>
