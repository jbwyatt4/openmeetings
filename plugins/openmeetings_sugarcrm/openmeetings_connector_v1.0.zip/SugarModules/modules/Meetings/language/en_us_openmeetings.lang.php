<?php
// created: 2008-06-06 11:53:13
$mod_strings = array_merge($mod_strings,
    array(
 'VALUE' => 'OPENMEETINGS meeting',
  'LBL_IS_OPENMEETINGS' => 'Onlinemeeting',  
  'LBL_OPENMEETINGS_ROOMNAME' => 'Access Room',    
  'LBL_OPENMEETINGS_STARTADHOC' => 'My OpenMeetings Room', 
       
   )
  )
  ;


?>
