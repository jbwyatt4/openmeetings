<?php
// created: 20010-10-06 11:53:13
$mod_strings = array_merge($mod_strings,
    array(
 'VALUE' => 'OPENMEETINGS admin', 
  'LBL_OPENMEETINGS_PASS' => 'Password', 
  'LBL_OPENMEETINGS_ROOMNAME' => 'Roomname',
  'LBL_OPENMEETINGS_STARTADHOC' => 'My OpenMeetings Room',  
  'OPENMEETINGS_USERNAME'=>'Username',     
   'OPENMEETINGS_LINK_EDIT'=>'Openmeetings Account',
   'OPENMEETINGS_URL'=>'Openmeetings web address', 
   'OPENMEETINGS_HTTP_PORT'=>'OpenMeetings/Red5 server http Port',   
   'OPENMEETINGS_LANGUAGE'=>'Conference Language',
   'OPENMEETINGS_HTTP_PORT'=>'OpenMeetings/Red5 server http Port',
	'OPENMEETINGS_ACC_SETT'=>'Openmeetings Account Login',         
   )
  );


?>
